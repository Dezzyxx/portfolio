import random

def generate_hint(number_to_guess, attempts):
    hints = [
        "The number is even." if number_to_guess % 2 == 0 else "The number is odd.",
        f"The number is {'greater' if number_to_guess > 25 else 'less'} than 25.",
        "The number is a multiple of 5." if number_to_guess % 5 == 0 else "The number is not a multiple of 5.",
        f"The number is {'greater' if number_to_guess > 10 else 'less'} than 10.",
        f"The number is {'greater' if number_to_guess > 30 else 'less'} than 30.",
        f"The number is {'greater' if number_to_guess > 40 else 'less'} than 40.",
        f"The number ends in {'0-4' if number_to_guess % 10 < 5 else '5-9'}.",
        "The number is a prime number." if is_prime(number_to_guess) else "The number is not a prime number.",
        "The number is a square number." if is_square(number_to_guess) else "The number is not a square number.",
        "The number is a Fibonacci number." if is_fibonacci(number_to_guess) else "The number is not a Fibonacci number."
    ]
    return hints[attempts]

def is_prime(num):
    if num < 2:
        return False
    for i in range(2, int(num**0.5) + 1):
        if num % i == 0:
            return False
    return True

def is_square(num):
    return int(num**0.5)**2 == num

def is_fibonacci(num):
    x, y = 0, 1
    while y < num:
        x, y = y, x + y
    return y == num or num == 0

def number_guessing_game():
    number_to_guess = random.randint(1, 50)
    max_attempts = 10
    attempts = 0
    score = 0

    print("Welcome to the Number Guessing Game!")
    print("I have selected a number between 1 and 50. Can you guess what it is?")
    print(f"You have {max_attempts} attempts. Let's begin!")

    while attempts < max_attempts:
        try:
            guess = int(input("Enter your guess: "))
            attempts += 1

            if guess < 1 or guess > 50:
                print("Please guess a number between 1 and 50.")
                attempts -= 1
                continue

            if guess < number_to_guess:
                print("Too low! Try again.")
            elif guess > number_to_guess:
                print("Too high! Try again.")
            else:
                print(f"Congratulations! You guessed the number in {attempts} attempts.")
                score += (max_attempts - attempts + 1) * 10
                break

            hint = generate_hint(number_to_guess, attempts - 1)
            print(f"Hint: {hint}")

        except ValueError:
            print("Invalid input. Please enter an integer.")
            attempts -= 1

    if attempts == max_attempts and guess != number_to_guess:
        print(f"Sorry, you've used all {max_attempts} attempts. The number was {number_to_guess}.")
        score -= 10

    print(f"Your final score is: {score}")

if __name__ == "__main__":
    number_guessing_game()
